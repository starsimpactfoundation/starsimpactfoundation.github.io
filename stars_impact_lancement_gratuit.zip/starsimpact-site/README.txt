STAR’S IMPACT — Site institutionnel bilingue (prototype)

Fichiers:
- index.html : site responsive FR/EN, navigation, présentation, mission, programmes,
  actions, contact de démonstration et aperçu de l'espace membre.

Prévisualisation:
- Ouvrir index.html dans un navigateur récent.

État:
- Prototype front-end statique.
- Le sélecteur FR/EN fonctionne côté navigateur.
- Le formulaire de contact et la connexion membre sont des démonstrations.
- Aucune donnée n'est envoyée ou conservée.

Avant la mise en production:
- choisir le domaine et l'hébergement;
- créer le backend et la base de données;
- configurer l'authentification sécurisée, les rôles et permissions;
- ajouter les coordonnées officielles et les contenus validés;
- prévoir sauvegardes et politique de confidentialité.
