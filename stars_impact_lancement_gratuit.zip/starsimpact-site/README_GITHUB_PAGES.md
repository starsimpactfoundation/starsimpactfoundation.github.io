# STAR’S IMPACT — Publication gratuite avec GitHub Pages

Ce dossier contient le prototype institutionnel bilingue (français / anglais).

## Publier gratuitement

1. Créer un compte sur https://github.com si la fondation n'en possède pas.
2. Créer un nouveau dépôt public nommé exactement `starsimpact.github.io`.
3. Importer à la racine du dépôt les fichiers `index.html` et `.nojekyll`.
4. Dans **Settings → Pages**, choisir **Deploy from a branch**, puis la branche `main` et le dossier `/ (root)`.
5. Enregistrer et attendre la publication. L'adresse sera alors :
   `https://starsimpact.github.io`

## Important

- La publication gratuite ne nécessite pas l'achat de `starsimpact.org`.
- Le nom de dépôt `starsimpact.github.io` doit être disponible et le compte GitHub doit être sous le contrôle de la fondation.
- Le prototype actuel est un site statique : les formulaires et la connexion membre sont des démonstrations uniquement.
- Ne jamais collecter de mots de passe, pièces d'identité ou paiements via cette version.
- L'espace membre réel nécessitera ultérieurement un backend, une base de données et une authentification sécurisée.
- Avant publication, remplacer ou confirmer les coordonnées, textes, visuels et informations institutionnelles.
